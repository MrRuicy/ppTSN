[简体中文](../../zh-CN/tutorials/customized_usage.md) | English

在了解了PaddleVideo整体架构后，我们看下如何自定义一个数据集，或是自定义一个网络结构，并实际应用上
