简体中文 | [English](../en/tools.md)

# 小工具

这篇文档主要介绍PaddleVideo的一些小工具

## 统计 Params

```shell
python3.7 tools/summary.py -c configs/recognition/tsm/tsm.yaml
```

## 统计FLOPS

```shell
python3.7 tools/summary.py -c configs/recognition/tsm/tsm.yaml --FLOPs
```

## 测试导出模型 <sup>coming soon</sup>
