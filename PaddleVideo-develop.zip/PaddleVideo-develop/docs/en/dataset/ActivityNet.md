English | [简体中文](../../zh-CN/dataset/ActivityNet.md)

# Usage of ActivityNet 1.3

We have preprocessed mp4 file, you can easily get our [feature data](https://paddlemodels.bj.bcebos.com/video_detection/bmn_feat.tar.gz) and [label data](https://paddlemodels.bj.bcebos.com/video_detection/activitynet_1.3_annotations.json).
Then you should specify the data path as `feat_path` and `file_path` in config file `configs/localization/bmn.yaml` .
