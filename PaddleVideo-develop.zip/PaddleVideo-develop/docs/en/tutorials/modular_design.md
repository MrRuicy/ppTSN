[简体中文](../../zh-CN/tutorials/modular_design.md) | English
