[简体中文](../zh-CN/tools.md) | English

# Tools

This page includes the usage of some useful tools in PaddleVideo.

## Params

To get the params of a model.

```shell
python3.7 tools/summary.py -c configs/recognization/tsm/tsm.yaml
```

## FLOPS
to print FLOPs.

```shell
python3.7 tools/summary.py -c configs/recognization/tsm/tsm.yaml --FLOPs
```

## Test the export model <sup>coming soon</sup>
